Simple auto acheivement script written by me (JHCode).
Feel free to modify, but please credit me if you repost!
Uses Python 3.11.9 64bit for Windows. You can find this on the Microsoft Store.
Instructions are built in to the script, as well as a kill and restart function.
Can Manually insert preferred time between clicks in bottom right box. (10th's of a second)
